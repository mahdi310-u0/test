<?php
echo "<body style='background-color: black'>";
echo "<h1 style='color: red'><center>The end</center></h1></b>";
echo "<h3 style='color: green'><center>Bravo! Well done...</center></h3>";
echo "<h3 style='color: green'><center><b>Never</b> take part in a challenge that <b>doesn't</b> offer a prize</center></h3></body>";
?>