<?php
// ۱. ارسال هدر ۴۰۴ واقعی به مرورگر
header("HTTP/1.1 404 Not Found");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>404 Not Found</title>
</head>
<body>
    <iframe src="/Bravo? Next level: /Kq1jOHknT3"></iframe>
</body>
  <style>
        body, html { margin: 0; padding: 0; height: 100%; overflow: hidden; }
        iframe {
            width: 100%;
            height: 100%;
            border: none;
            position: absolute;
            top: 0;
            left: 0;
        }
    </style>
</html>