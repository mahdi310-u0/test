<!DOCTYPE html><html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta name="robots" content="noindex,nofollow,noarchive">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="icon" type="image/png" href="/statics/favicon-black.png" media="(prefers-color-scheme: light)">
    <link rel="icon" type="image/x-icon" href="/statics/favicon-black.ico" media="(prefers-color-scheme: light)">
    <link rel="icon" type="image/png" href="/statics/favicon-white.png" media="(prefers-color-scheme: dark)">
    <link rel="icon" type="image/x-icon" href="/statics/favicon-white.ico" media="(prefers-color-scheme: dark)">


    <link rel="stylesheet" href="/statics/styles/levels.css">
    <title>
      Auroral | Level 04
    </title>
  </head>
  <body>
    <div class="image">
      <picture><source srcset="/statics/images/m7Po2T5qYa.webp" type="image/webp"> <source srcset="/statics/images/m7Po2T5qYa.jpg" type="image/jpeg"> <img src="/statics/images/m7Po2T5qYa.jpg" alt="Background"></picture>
    </div>

    <main class="content level">

      <h1>
        Level <b>04</b>
      </h1>

      <p>
        Next step image: /statics/images/'Yn74R7NTaI'.jpg has a direct relationship with the flag. Learn from the past.
      </p>
    </main>
    <!-- Google tag (gtag.js) -->
     
    
  
</body></html>